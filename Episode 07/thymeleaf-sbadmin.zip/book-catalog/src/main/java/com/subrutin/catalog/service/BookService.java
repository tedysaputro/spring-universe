package com.subrutin.catalog.service;

import java.util.List;

import com.subrutin.catalog.form.BookForm;
import com.subrutin.catalog.model.Book;

public interface BookService {

	public List<Book> findBookAll();
	
	public void createANewBook(BookForm bookForm);
}

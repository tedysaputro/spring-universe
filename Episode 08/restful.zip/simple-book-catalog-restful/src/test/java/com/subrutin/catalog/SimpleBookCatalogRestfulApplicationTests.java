package com.subrutin.catalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleBookCatalogRestfulApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.subrutin.catalog.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.subrutin.catalog.domain.Book;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {

	//select * from Book where title LIKE 'nama';
	List<Book> findAllByTitleLike(String title);
	
}

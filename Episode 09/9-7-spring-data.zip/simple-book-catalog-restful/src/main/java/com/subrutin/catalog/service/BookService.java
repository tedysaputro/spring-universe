package com.subrutin.catalog.service;

import java.util.List;

import com.subrutin.catalog.dto.BookCreateRequestDTO;
import com.subrutin.catalog.dto.BookDetailResponseDTO;
import com.subrutin.catalog.dto.BookListResponseDTO;
import com.subrutin.catalog.dto.BookUpdateRequestDTO;
import com.subrutin.catalog.model.Book;

public interface BookService {

	public List<BookListResponseDTO> findBookAll();
	
	public void createNewBook(BookCreateRequestDTO dto);
	
	public BookDetailResponseDTO findBookDetail(String bookId);
	
	public void updateBook(String bookId, BookUpdateRequestDTO dto);
	
	public void deleteBook(String bookId);
	
}
